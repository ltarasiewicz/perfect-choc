jQuery(document).ready(function($) {

    "use strict";

	$('#portfolio_color_meta_box').wpColorPicker();
	 
});